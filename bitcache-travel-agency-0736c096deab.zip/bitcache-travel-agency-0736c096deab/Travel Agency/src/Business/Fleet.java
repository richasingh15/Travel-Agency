/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Fleet {
    
    private Airliners airliners;
    private ArrayList<Airplane> listofAirplanes;
    
    public Fleet(){
        
        listofAirplanes = new ArrayList<Airplane>();
    }

    public Airliners getAirliners() {
        return airliners;
    }

    public void setAirliners(Airliners airliners) {
        this.airliners = airliners;
    }

    public ArrayList<Airplane> getListofAirplanes() {
        return listofAirplanes;
    }

    public void setListofAirplanes(ArrayList<Airplane> listofAirplanes) {
        this.listofAirplanes = listofAirplanes;
    }
    
    public Airplane addAirplane(){
        
        Airplane airplane = new Airplane();
        listofAirplanes.add(airplane);
        return airplane;
    }
    
    public void delAirplane(Airplane a){
        
        listofAirplanes.remove(a);
    }
}
